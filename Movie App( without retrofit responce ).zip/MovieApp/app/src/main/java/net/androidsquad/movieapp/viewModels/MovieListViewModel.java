package net.androidsquad.movieapp.viewModels;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import net.androidsquad.movieapp.models.MovieModel;
import net.androidsquad.movieapp.repositories.MovieRepository;

import java.util.List;

public class MovieListViewModel extends ViewModel {

    // This class is used for VIEW MODEL

    ////private MutableLiveData<List<MovieModel>> mMovies = new MutableLiveData<>();

    private MovieRepository movieRepository;

    // Constructor
//    public MovieListViewModel(MutableLiveData<List<MovieModel>> mMovies) {
//        this.mMovies = mMovies;
//    }
    public MovieListViewModel() {
        movieRepository = MovieRepository.getInstance();
    }


    public LiveData<List<MovieModel>> getMovies() {
        return movieRepository.getMovies();             //movieRepository.getMovies();
    }


//    public MutableLiveData<List<MovieModel>> getmMovies() {
//        return mMovies;
////    }

    public void searchMoviesApi(String query, int pageNumber){
        movieRepository.searchMoviesApi(query, pageNumber);
    }





}
