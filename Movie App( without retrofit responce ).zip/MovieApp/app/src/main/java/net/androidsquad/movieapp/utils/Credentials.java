package net.androidsquad.movieapp.utils;

public class Credentials {

    public static final String BASE_URL = "https://api.themoviedb.org";

    public static final String API_KEY = "73222626ebb24678faae05d8360cb3e2";


}
