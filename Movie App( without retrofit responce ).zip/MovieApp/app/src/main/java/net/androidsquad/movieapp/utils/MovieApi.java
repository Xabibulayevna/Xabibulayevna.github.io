package net.androidsquad.movieapp.utils;

import net.androidsquad.movieapp.models.MovieModel;
import net.androidsquad.movieapp.response.MovieSearchResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface MovieApi {

    // Search for movies
    // https://api.themoviedb.org/3/search/movie?api_key=73222626ebb24678faae05d8360cb3e2&query=iron    &page=2
    @GET("3/search/movie?")
    Call<MovieSearchResponse> searchMovie(
        @Query("api_key") String api_key,
        @Query("query") String query,
        @Query("page") int page    //Query("page") int page
    );


    // Search for movie_id
    //  https://api.themoviedb.org/3/movie/343611?api_key=73222626ebb24678faae05d8360cb3e2
    //  Remenber that
    @GET("3/movie/{movie_id}?")
    Call<MovieModel> getMovie(
            @Path("movie_id") int movie_id,  // 343611, Jack Reacher: Never Go Back
            @Query("api_key") String api_key
    );




}
