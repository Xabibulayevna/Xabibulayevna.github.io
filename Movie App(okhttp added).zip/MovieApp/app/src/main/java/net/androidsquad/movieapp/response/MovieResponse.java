package net.androidsquad.movieapp.response;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import net.androidsquad.movieapp.models.MovieModel;

// This class for single movie request with query, like "Iron Man"
public class MovieResponse {

    // 1 - Finding the movie object
    @SerializedName("results")
    @Expose

    private MovieModel movie;

    public MovieModel getMovie(){
        return movie;
    }

    @Override
    public String toString() {
        return "MovieResponse{" +
                "movie=" + movie +
                '}';
    }
}
