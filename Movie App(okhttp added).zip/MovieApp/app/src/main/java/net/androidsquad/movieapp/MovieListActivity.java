package net.androidsquad.movieapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import net.androidsquad.movieapp.models.MovieModel;
import net.androidsquad.movieapp.request.Servicey;
import net.androidsquad.movieapp.response.MovieSearchResponse;
import net.androidsquad.movieapp.utils.Credentials;
import net.androidsquad.movieapp.utils.MovieApi;
import net.androidsquad.movieapp.viewModels.MovieListViewModel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MovieListActivity extends AppCompatActivity {

    Button btn;
    private static final String TAG = "TAG";

    // ViewModel
    private MovieListViewModel movieListViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);

        movieListViewModel = ViewModelProviders.of(this).get(MovieListViewModel.class);



        findViewById(R.id.btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ObserveAnyChange();
//                GetRetrofityResponseAccordingToID();
                testRetrofitRequest();
            }
        });

    }


    // Observing any data changes
private void ObserveAnyChange() {
        movieListViewModel.getMovies().observe(this, new Observer<List<MovieModel>>() {
            @Override
            public void onChanged( List<MovieModel> movieModels) {      // @Nullable
                // Observing any data change
                if(movieModels != null) {
                    for (MovieModel movieModel : movieModels) {
                        Log.d(TAG, "onChanged: " + movieModel.getTitle());
                    }
                }
            }
        });
    }


    private void searchMoviesApi(String query, int pageNumber){
//        movieListViewModel.searchMoviesApi(query, pageNumber);
        movieListViewModel.searchMoviesApi(query, pageNumber);

    }

    private void testRetrofitRequest(){
        searchMoviesApi("Iron", 1);
    }





    private void GetRetrofitResponse() {
        MovieApi movieApi = Servicey.getMovieApi();

        Call<MovieSearchResponse> responseCall = movieApi
                .searchMovie(
                        Credentials.API_KEY,
                        "Iron",
                         1
                );

        responseCall.enqueue(new Callback<MovieSearchResponse>() {
            @Override
            public void onResponse(Call<MovieSearchResponse> call, Response<MovieSearchResponse> response) {
                if (response.code() == 200) {
                    Log.d(TAG, "onResponse: the response" + response.body().toString());

                    List<MovieModel> movies = new ArrayList<>(response.body().getMovies());

                    for (MovieModel movie : movies) {
                        Log.d(TAG, "onResponse: Title " + movie.getTitle());
                    }
                } else {
                    try {
                        Log.d(TAG, "onResponse: " + response.errorBody().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<MovieSearchResponse> call, Throwable t) {
            }
        });
    }



    private void GetRetrofityResponseAccordingToID(){
        MovieApi movieApi = Servicey.getMovieApi();

        Call<MovieModel> responseCall = movieApi
                .getMovie(
                        343611, /// Jack Reacher: Never Go Back
                        Credentials.API_KEY);

        responseCall.enqueue(new Callback<MovieModel>() {
            @Override
            public void onResponse(Call<MovieModel> call, Response<MovieModel> response) {
                if( response.code() == 200 ) {
                    MovieModel movie = response.body();
                    Log.v(TAG, "onResponse: Response " + movie.getTitle());
                } else {
                    try {
                        Log.v(TAG, "onResponse: Error " + response.errorBody().string());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<MovieModel> call, Throwable t) {

            }
        });

    }

}


