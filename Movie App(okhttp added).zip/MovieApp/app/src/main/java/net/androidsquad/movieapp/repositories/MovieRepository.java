package net.androidsquad.movieapp.repositories;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import net.androidsquad.movieapp.models.MovieModel;
import net.androidsquad.movieapp.request.MovieApiClient;
import net.androidsquad.movieapp.utils.MovieApi;

import java.util.List;

public class MovieRepository {

    // This class acts as repository
    private static MovieRepository instance;

    private MovieApiClient movieApiClient;

    public static MovieRepository getInstance() {
        if (instance == null) {
            instance = new  MovieRepository();
        }
        return instance;
    }

    private MovieRepository() {
        movieApiClient = MovieApiClient.getInstance();
    }


//        movieApiClient = MovieApiClient.getInstatnce();
////        mMovies = new MutableLiveData<>();
////    }
//
//    public MovieApiClient getMovieApiClient() {
//        return movieApiClient;
//    }

    public LiveData<List<MovieModel>> getMovies() {
        return movieApiClient.getmovies();
    }
    public void searchMoviesApi(String query, int pageNumber){
        if (pageNumber==0){
            pageNumber=1;
        }
        movieApiClient.searchMoviesApi(query, pageNumber);
    }
}

