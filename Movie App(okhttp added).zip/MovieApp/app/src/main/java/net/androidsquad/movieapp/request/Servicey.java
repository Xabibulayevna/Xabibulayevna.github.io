package net.androidsquad.movieapp.request;

import net.androidsquad.movieapp.utils.Credentials;
import net.androidsquad.movieapp.utils.MovieApi;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class Servicey {

    private static final Retrofit retrofit =
            new Retrofit.Builder()
            .baseUrl(Credentials.BASE_URL)
            .client(getOkhttpClient())
            .addConverterFactory(GsonConverterFactory.create())
            .build();

    public static MovieApi movieApi = null;

    public static MovieApi getMovieApi() {
        if (movieApi == null) {
            movieApi = retrofit.create(MovieApi.class);
        }
        return movieApi;
    }

    private static OkHttpClient getOkhttpClient() {
        final HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        return new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build();
    }
}






//public class Servicey {
//
//    public static Retrofit.Builder retrofitBuilder =
//            new Retrofit.Builder()
//            .baseUrl(Credentials.BASE_URL)
//            .addConverterFactory(GsonConverterFactory.create());
//
//    public static Retrofit retrofit = retrofitBuilder.build();
//
//    public static MovieApi movieApi = retrofit.create(MovieApi.class);
//
//    public static MovieApi getMovieApi() {
//        return movieApi;
//    }
//}
